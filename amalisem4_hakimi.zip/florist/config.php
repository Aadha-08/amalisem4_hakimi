<?php 
// isi database 'florist' 
  $connect = mysqli_connect('localhost', 'root', '', 'florist') or die('Failed to connect to db.') ; 
?>