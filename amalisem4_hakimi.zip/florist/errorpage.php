<!DOCTYPE html>
<html>
<head>
    <title>Ralat Sistem</title>
</head>
<body style="text-align: center; padding-top: 100px; font-family: Arial;">
    <h1 style="color: red;">Ops! Sesuatu Telah Berlaku</h1>
    <p>Maaf, sistem tidak dapat memproses permintaan anda buat masa ini.</p>
    <a href="index.php" style="text-decoration: none; color: blue;">Kembali ke Halaman Utama</a>
</body>
</html>